#pragma once
#include <fstream>
#include <iostream>
#include <string>


using namespace std;

class user {
public:
	string userEmail, userType, userNumber, userName, useremail, userPassword, userVid;
};

class database  {
	string userEmail, userType, userNumber, userName, useremail, userPassword, userVid;
	int availableParking, totalParking, occupiedParking, currentUser, logindex;

public:

	bool create(user userData[]);
	void read(int readType, string userEmail, string password);
	void update(string userName, string userType, string userNumber, string userEmail, string password);
	void del();
	//void userinfo();
	void parkinginfo();
	void fetchData();
	void viewData();

};

void database::viewData() {
	fstream userfile;
	user userD[5];
	string usertype = "normal";
	userType = usertype;
	int j = 0;
	userfile.open("D:/ParkingManagement/user.dat", ios::in | ios::binary);
	userfile.read((char*)&userD, sizeof(userD));

	for (j; j < 5; j++) {
		userEmail = userD[j].userEmail;
		userName = userD[j].userName;
		userNumber = userD[j].userNumber;
		userPassword = userD[j].userPassword;
		userVid = userD[j].userVid;
		cout << "Enter your name : " << userName << endl;
		cout << "Enter your Email : " << userEmail << endl;
		cout << "Enter your number : " << userNumber << endl;
		cout << "Enter your vehicle registeration number : " << userVid << endl;
		cout << "Enter your password : " << userPassword << endl;
	}
	userfile.close();
}

void database::fetchData() {
	int i = 0;
	char res;
	fstream userfile;
	user userD[5];
	string usertype = "normal";
	userType = usertype;
	//	userfile.open("D:/ParkingManagement/log.dat", ios::in | ios::binary);
		//userfile.read((char*)&i, sizeof(i));
	for (int i = 0; i < 5; i++) {

		cout << "Do you want to enter data : ";
		cin >> res;
		if (res == 'y') {
			cout << "Enter your name : " << endl;
			cin >> userD[i].userName;
			cout << "Enter your Email : " << endl;
			cin >> userD[i].userEmail;
			cout << "Enter your number : " << endl;
			cin >> userD[i].userNumber;
			cout << "Enter your vehicle registeration number : " << endl;
			cin >> userD[i].userVid;
			cout << "Enter your password : " << endl;
			cin >> userD[i].userPassword;
			logindex = i;
			userfile.open("D:/ParkingManagement/user.dat", ios::out | ios::app | ios::binary);
			if (userfile.is_open()) {

				userfile.write((char*)&userD[i], sizeof(user));
				//create(&userD[i]);
			}
			else {
				break;
			}

		}
		userfile.close();
		//create(userD);


	}
}

void database::parkinginfo() {

	cout << "Available Parking : " << endl;
	cout << availableParking;
	cout << "Occupied Parking : " << endl;
	cout << occupiedParking;
	cout << "Total Parking : " << endl;
	cout << totalParking;

}

bool database::create(user userData[5]) {

	fstream userfile;
	userfile.open("D:/ParkingManagement/user.dat", ios::out | ios::app | ios::binary);
	if (userfile.is_open()) {

		userfile.write((char*)userData, sizeof(userData));
	}
	else {
		cout << "!File missing";
	}


	userfile.close();
	return 0;
}

void database::read(int readType, string userEmail, string password) {

	fstream userfile;

	// Read type : 1:all 2:login 3:custom 4: reading parking count 5: reading available parking 



	if (readType == 1) {


		userfile.open("D:/ParkingManagement/user.dat", ios::in | ios::binary);
		viewData();
		userfile.close();
	}
	else if (readType == 2) {

	}
	else if (readType == 4) {

	}
	else {
		cout << "enter param";

	}


}

void database::update(string userName, string userType, string userNumber, string userEmail, string password) {


}

void database::del() {


}


