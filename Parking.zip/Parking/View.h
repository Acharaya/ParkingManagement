#pragma once
#include <iostream>
#include <stdlib.h>
#include "Database.h"
using namespace std;

class view {

public:
	void user();
	void admin();
	void controller();
	void general();
};

void view::general() {
	string email, name, usertype = "normal", password, number, vehicleid;

	int choice, exits = 0;
	database db;
	string data;
	char res;

	cout << "PARKING ASAP" << endl;
	cout << "To exit type 'yes' or press y" << endl;
	cout << "1: Register" << endl;
	cout << "2: Login" << endl;
	cout << "3: Exit" << endl;
	cout << "4: Parking Information" << endl;
	cout << "5: View" << endl;
	cout << "5: Clear screen" << endl;

	while (exits != 1) {

		cout << "\nEnter your input : " << endl;
		cin >> choice;
		switch (choice) {
		case 1:
			db.fetchData();
		
			break;
		case 2:
			cout << "Email : " << endl;
			cin >> email;
			cout << "Password : " << endl;
			cin >> password;
			db.read(2, email, password);
			break;
		case 3:
			exits = 1;
			break;
		case 4:
			db.read(4, " ", "");
			break;
		case 5:
			db.read(1, "", "");
			break;
		case 6:
			system("CLS");
			break;
		default:
			cout << "Please enter valid input";
			exits = 1;
			break;
		}


	}

}

void view::admin() {

	cout << "PARKING ASAP";


}

void view::user() {


}

void view::controller() {


}